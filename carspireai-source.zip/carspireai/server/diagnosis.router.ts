import { z } from "zod";
import { protectedProcedure, router } from "./_core/trpc";
import { diagnoseCarIssue } from "./gemini";
import { createDiagnosis, getUserDiagnoses } from "./db";

export const diagnosisRouter = router({
  /**
   * Submit a car diagnosis request
   * Accepts car model, issue description, and optional image/video for multimodal analysis
   */
  submit: protectedProcedure
    .input(
      z.object({
        carModel: z.string().min(1, "Car model is required"),
        issue: z.string().min(1, "Issue description is required"),
        imageBase64: z.string().optional(),
        videoBase64: z.string().optional(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      try {
        // Call Gemini API for diagnosis
        const diagnosis = await diagnoseCarIssue(
          input.carModel,
          input.issue,
          input.imageBase64,
          input.videoBase64
        );

        // Save diagnosis to database
        const result = await createDiagnosis({
          userId: ctx.user.id,
          carModel: input.carModel,
          issue: input.issue,
          imageUrl: input.imageBase64 ? "image_stored" : undefined,
          videoUrl: input.videoBase64 ? "video_stored" : undefined,
          diagnosis: JSON.stringify(diagnosis),
        });

        return {
          success: true,
          diagnosis,
        };
      } catch (error) {
        console.error("Diagnosis error:", error);
        throw new Error(
          error instanceof Error ? error.message : "Failed to process diagnosis"
        );
      }
    }),

  /**
   * Get user's diagnosis history
   */
  history: protectedProcedure.query(async ({ ctx }) => {
    const diagnoses = await getUserDiagnoses(ctx.user.id);
    return diagnoses.map((d) => ({
      id: d.id,
      carModel: d.carModel,
      issue: d.issue,
      createdAt: d.createdAt,
      diagnosis: JSON.parse(d.diagnosis),
    }));
  }),
});
