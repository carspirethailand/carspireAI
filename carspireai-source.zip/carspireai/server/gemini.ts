import { GoogleGenerativeAI } from "@google/generative-ai";

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY || "");

export interface DiagnosisResult {
  steps: string[];
  videoLinks: { title: string; url: string }[];
  parts: { name: string; availability: string }[];
}

/**
 * Process car diagnosis using Google Gemini API with multimodal support
 * @param carModel - The car model
 * @param issue - Description of the car issue
 * @param imageBase64 - Optional base64 encoded image
 * @param videoBase64 - Optional base64 encoded video
 * @returns Structured diagnosis result
 */
export async function diagnoseCarIssue(
  carModel: string,
  issue: string,
  imageBase64?: string,
  videoBase64?: string
): Promise<DiagnosisResult> {
  const model = genAI.getGenerativeModel({ model: "gemini-2.5-flash" });

  // Build the prompt
  const prompt = `You are an expert automotive mechanic and diagnostician. A user has reported an issue with their car.

Car Model: ${carModel}
Issue Description: ${issue}

Please analyze this car issue and provide:
1. Step-by-step repair instructions (numbered list)
2. Relevant YouTube tutorial links (search suggestions with URLs)
3. Car parts that might need replacement with their availability status

Format your response as JSON with this exact structure:
{
  "steps": ["Step 1 description", "Step 2 description", ...],
  "videoLinks": [
    {"title": "Tutorial title", "url": "https://www.youtube.com/results?search_query=..."},
    ...
  ],
  "parts": [
    {"name": "Part name", "availability": "Common/Rare/Specialty"},
    ...
  ]
}

Only return valid JSON, no additional text.`;

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const parts: any[] = [{ text: prompt }];

  // Add image if provided
  if (imageBase64) {
    parts.push({
      inlineData: {
        mimeType: "image/jpeg",
        data: imageBase64,
      },
    });
  }

  // Add video if provided
  if (videoBase64) {
    parts.push({
      inlineData: {
        mimeType: "video/mp4",
        data: videoBase64,
      },
    });
  }

  try {
    const result = await model.generateContent({
      contents: [
        {
          role: "user",
          parts,
        },
      ],
    });

    const responseText =
      result.response.candidates?.[0]?.content?.parts?.[0]?.text || "{}";

    // Parse the JSON response
    const diagnosis = JSON.parse(responseText) as DiagnosisResult;

    // Validate the response structure
    if (!diagnosis.steps || !diagnosis.videoLinks || !diagnosis.parts) {
      throw new Error("Invalid diagnosis response structure");
    }

    return diagnosis;
  } catch (error) {
    console.error("Gemini API error:", error);
    throw new Error("Failed to diagnose car issue. Please try again.");
  }
}
