import { describe, expect, it, vi, beforeEach } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAuthContext(): TrpcContext {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "test-user",
    email: "test@example.com",
    name: "Test User",
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  const ctx: TrpcContext = {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };

  return ctx;
}

describe("diagnosis router", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("should submit a diagnosis request with required fields", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.diagnosis.submit({
      carModel: "Toyota Camry 2020",
      issue: "Engine making strange noise",
    });

    expect(result).toHaveProperty("success");
    expect(result).toHaveProperty("diagnosis");
    expect(result.diagnosis).toHaveProperty("steps");
    expect(result.diagnosis).toHaveProperty("videoLinks");
    expect(result.diagnosis).toHaveProperty("parts");
    expect(Array.isArray(result.diagnosis.steps)).toBe(true);
    expect(Array.isArray(result.diagnosis.videoLinks)).toBe(true);
    expect(Array.isArray(result.diagnosis.parts)).toBe(true);
  });

  it("should reject submission without car model", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    try {
      await caller.diagnosis.submit({
        carModel: "",
        issue: "Engine making strange noise",
      });
      expect.fail("Should have thrown an error");
    } catch (error) {
      expect(error).toBeDefined();
    }
  });

  it("should reject submission without issue description", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    try {
      await caller.diagnosis.submit({
        carModel: "Toyota Camry 2020",
        issue: "",
      });
      expect.fail("Should have thrown an error");
    } catch (error) {
      expect(error).toBeDefined();
    }
  });

  it("should retrieve user diagnosis history", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    // First, submit a diagnosis
    await caller.diagnosis.submit({
      carModel: "Honda Civic 2019",
      issue: "Brake pedal feels soft",
    });

    // Then retrieve history
    const history = await caller.diagnosis.history();

    expect(Array.isArray(history)).toBe(true);
    if (history.length > 0) {
      const firstDiagnosis = history[0];
      expect(firstDiagnosis).toHaveProperty("id");
      expect(firstDiagnosis).toHaveProperty("carModel");
      expect(firstDiagnosis).toHaveProperty("issue");
      expect(firstDiagnosis).toHaveProperty("diagnosis");
    }
  });

  it("should return properly structured diagnosis results", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.diagnosis.submit({
      carModel: "Ford F-150 2018",
      issue: "Transmission slipping",
    });

    const diagnosis = result.diagnosis;

    // Verify steps structure
    expect(diagnosis.steps.length).toBeGreaterThan(0);
    diagnosis.steps.forEach((step) => {
      expect(typeof step).toBe("string");
      expect(step.length).toBeGreaterThan(0);
    });

    // Verify video links structure
    diagnosis.videoLinks.forEach((link) => {
      expect(link).toHaveProperty("title");
      expect(link).toHaveProperty("url");
      expect(typeof link.title).toBe("string");
      expect(typeof link.url).toBe("string");
    });

    // Verify parts structure
    diagnosis.parts.forEach((part) => {
      expect(part).toHaveProperty("name");
      expect(part).toHaveProperty("availability");
      expect(typeof part.name).toBe("string");
      expect(typeof part.availability).toBe("string");
    });
  });
});
