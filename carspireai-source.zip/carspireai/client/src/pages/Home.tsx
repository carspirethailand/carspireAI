import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { trpc } from "@/lib/trpc";
import { getLoginUrl } from "@/const";
import { Loader2, Upload, Zap } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import DiagnosisForm from "@/components/DiagnosisForm";
import DiagnosisResults from "@/components/DiagnosisResults";

interface DiagnosisData {
  steps: string[];
  videoLinks: { title: string; url: string }[];
  parts: { name: string; availability: string }[];
}

export default function Home() {
  const { user, isAuthenticated } = useAuth();
  const [diagnosis, setDiagnosis] = useState<DiagnosisData | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const submitMutation = trpc.diagnosis.submit.useMutation();

  const handleSubmit = async (
    carModel: string,
    issue: string,
    imageFile?: File,
    videoFile?: File
  ) => {
    setIsLoading(true);
    try {
      let imageBase64: string | undefined;
      let videoBase64: string | undefined;

      // Convert image to base64
      if (imageFile) {
        imageBase64 = await fileToBase64(imageFile);
      }

      // Convert video to base64
      if (videoFile) {
        videoBase64 = await fileToBase64(videoFile);
      }

      const result = await submitMutation.mutateAsync({
        carModel,
        issue,
        imageBase64,
        videoBase64,
      });

      setDiagnosis(result.diagnosis);
      toast.success("Diagnosis complete!");
    } catch (error) {
      console.error("Diagnosis error:", error);
      toast.error(
        error instanceof Error ? error.message : "Failed to process diagnosis"
      );
    } finally {
      setIsLoading(false);
    }
  };

  const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => {
        const result = reader.result as string;
        // Extract base64 part (remove data:image/jpeg;base64, prefix)
        const base64 = result.split(",")[1];
        resolve(base64);
      };
      reader.onerror = reject;
    });
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50 flex items-center justify-center p-4">
        <Card className="w-full max-w-md p-8 shadow-lg">
          <div className="text-center mb-8">
            <div className="flex items-center justify-center gap-2 mb-4">
              <Zap className="w-8 h-8 text-blue-600" />
              <h1 className="text-3xl font-bold text-gray-900">CarspireAI</h1>
            </div>
            <p className="text-sm font-semibold text-blue-600 mb-2">(Demo)</p>
            <p className="text-gray-600">
              AI-powered car diagnosis at your fingertips
            </p>
          </div>

          <p className="text-gray-700 mb-6 text-center">
            Sign in to get started with intelligent car diagnostics powered by
            AI.
          </p>

          <a href={getLoginUrl()}>
            <Button className="w-full bg-blue-600 hover:bg-blue-700 text-white rounded-full py-3 font-semibold">
              Sign In to Continue
            </Button>
          </a>

          <p className="text-xs text-gray-500 text-center mt-6">
            Powered by Google Gemini AI
          </p>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
        <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Zap className="w-7 h-7 text-blue-600" />
            <h1 className="text-2xl font-bold text-gray-900">CarspireAI</h1>
            <span className="text-xs font-semibold text-blue-600 bg-blue-100 px-2 py-1 rounded-full">
              Demo
            </span>
          </div>
          <div className="text-sm text-gray-600">
            Welcome, {user?.name || "User"}
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-6xl mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Form Section */}
          <div>
            <Card className="p-6 shadow-lg">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">
                Diagnose Your Car
              </h2>
              <DiagnosisForm
                onSubmit={handleSubmit}
                isLoading={isLoading}
              />
            </Card>
          </div>

          {/* Results Section */}
          <div>
            {isLoading ? (
              <Card className="p-12 shadow-lg flex flex-col items-center justify-center min-h-96 bg-gradient-to-br from-blue-50 to-indigo-50">
                <div className="text-center">
                  <Loader2 className="w-12 h-12 text-blue-600 animate-spin mx-auto mb-4" />
                  <p className="text-gray-700 font-semibold">
                    Analyzing your car issue...
                  </p>
                  <p className="text-sm text-gray-500 mt-2">
                    Our AI is processing your request
                  </p>
                  <div className="mt-6 w-full bg-gray-200 rounded-full h-2">
                    <div className="bg-blue-600 h-2 rounded-full animate-pulse w-3/4"></div>
                  </div>
                </div>
              </Card>
            ) : diagnosis ? (
              <DiagnosisResults diagnosis={diagnosis} />
            ) : (
              <Card className="p-12 shadow-lg flex flex-col items-center justify-center min-h-96 bg-gradient-to-br from-blue-50 to-indigo-50">
                <Upload className="w-12 h-12 text-gray-400 mb-4" />
                <p className="text-gray-600 text-center">
                  Submit a diagnosis request to see results here
                </p>
              </Card>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}
