import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Upload, X } from "lucide-react";
import { useState } from "react";

interface DiagnosisFormProps {
  onSubmit: (
    carModel: string,
    issue: string,
    imageFile?: File,
    videoFile?: File
  ) => Promise<void>;
  isLoading: boolean;
}

export default function DiagnosisForm({
  onSubmit,
  isLoading,
}: DiagnosisFormProps) {
  const [carModel, setCarModel] = useState("");
  const [issue, setIssue] = useState("");
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [videoFile, setVideoFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setImageFile(file);
      const reader = new FileReader();
      reader.onload = (event) => {
        setImagePreview(event.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleVideoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setVideoFile(file);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!carModel.trim() || !issue.trim()) {
      alert("Please fill in all required fields");
      return;
    }
    await onSubmit(carModel, issue, imageFile || undefined, videoFile || undefined);
  };

  const clearImage = () => {
    setImageFile(null);
    setImagePreview(null);
  };

  const clearVideo = () => {
    setVideoFile(null);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-5">
      {/* Car Model Input */}
      <div>
        <label className="block text-sm font-semibold text-gray-700 mb-2">
          Car Model *
        </label>
        <Input
          type="text"
          placeholder="e.g., Toyota Camry 2020"
          value={carModel}
          onChange={(e) => setCarModel(e.target.value)}
          disabled={isLoading}
          className="w-full border-gray-300 focus:border-blue-500 focus:ring-blue-500"
        />
      </div>

      {/* Issue Description */}
      <div>
        <label className="block text-sm font-semibold text-gray-700 mb-2">
          Describe the Issue *
        </label>
        <Textarea
          placeholder="Describe what's wrong with your car. Be as detailed as possible..."
          value={issue}
          onChange={(e) => setIssue(e.target.value)}
          disabled={isLoading}
          rows={4}
          className="w-full border-gray-300 focus:border-blue-500 focus:ring-blue-500"
        />
      </div>

      {/* Image Upload */}
      <div>
        <label className="block text-sm font-semibold text-gray-700 mb-2">
          Upload Image (Optional)
        </label>
        {imagePreview ? (
          <div className="relative">
            <img
              src={imagePreview}
              alt="Preview"
              className="w-full h-48 object-cover rounded-lg border-2 border-blue-200"
            />
            <button
              type="button"
              onClick={clearImage}
              className="absolute top-2 right-2 bg-red-500 text-white rounded-full p-1 hover:bg-red-600"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        ) : (
          <label className="flex items-center justify-center w-full px-4 py-6 border-2 border-dashed border-blue-300 rounded-lg cursor-pointer hover:border-blue-500 bg-blue-50 transition">
            <div className="flex flex-col items-center justify-center">
              <Upload className="w-6 h-6 text-blue-600 mb-2" />
              <span className="text-sm font-medium text-blue-600">
                Click to upload image
              </span>
              <span className="text-xs text-gray-500">
                JPG, PNG up to 10MB
              </span>
            </div>
            <input
              type="file"
              accept="image/*"
              onChange={handleImageChange}
              disabled={isLoading}
              className="hidden"
            />
          </label>
        )}
      </div>

      {/* Video Upload */}
      <div>
        <label className="block text-sm font-semibold text-gray-700 mb-2">
          Upload Video (Optional)
        </label>
        {videoFile ? (
          <div className="flex items-center justify-between p-3 bg-blue-50 border border-blue-200 rounded-lg">
            <span className="text-sm text-gray-700">{videoFile.name}</span>
            <button
              type="button"
              onClick={clearVideo}
              className="text-red-500 hover:text-red-700"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        ) : (
          <label className="flex items-center justify-center w-full px-4 py-6 border-2 border-dashed border-blue-300 rounded-lg cursor-pointer hover:border-blue-500 bg-blue-50 transition">
            <div className="flex flex-col items-center justify-center">
              <Upload className="w-6 h-6 text-blue-600 mb-2" />
              <span className="text-sm font-medium text-blue-600">
                Click to upload video
              </span>
              <span className="text-xs text-gray-500">
                MP4, WebM up to 100MB
              </span>
            </div>
            <input
              type="file"
              accept="video/*"
              onChange={handleVideoChange}
              disabled={isLoading}
              className="hidden"
            />
          </label>
        )}
      </div>

      {/* Submit Button */}
      <Button
        type="submit"
        disabled={isLoading || !carModel.trim() || !issue.trim()}
        className="w-full bg-blue-600 hover:bg-blue-700 text-white rounded-full py-3 font-semibold transition disabled:opacity-50 disabled:cursor-not-allowed"
      >
        {isLoading ? "Analyzing..." : "Get AI Diagnosis"}
      </Button>

      <p className="text-xs text-gray-500 text-center">
        Powered by Google Gemini AI
      </p>
    </form>
  );
}
