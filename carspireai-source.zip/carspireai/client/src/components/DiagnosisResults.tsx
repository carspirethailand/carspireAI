import { Card } from "@/components/ui/card";
import { CheckCircle, ExternalLink, Package, Video } from "lucide-react";

interface DiagnosisResultsProps {
  diagnosis: {
    steps: string[];
    videoLinks: { title: string; url: string }[];
    parts: { name: string; availability: string }[];
  };
}

export default function DiagnosisResults({
  diagnosis,
}: DiagnosisResultsProps) {
  const getAvailabilityColor = (availability: string) => {
    switch (availability.toLowerCase()) {
      case "common":
        return "bg-green-100 text-green-800";
      case "rare":
        return "bg-yellow-100 text-yellow-800";
      case "specialty":
        return "bg-orange-100 text-orange-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <div className="space-y-6">
      {/* Steps Section */}
      <Card className="p-6 shadow-lg">
        <div className="flex items-center gap-2 mb-4">
          <CheckCircle className="w-6 h-6 text-blue-600" />
          <h3 className="text-xl font-bold text-gray-900">
            Step-by-Step Repair Guide
          </h3>
        </div>
        <ol className="space-y-3">
          {diagnosis.steps.map((step, index) => (
            <li key={index} className="flex gap-4">
              <div className="flex-shrink-0">
                <div className="flex items-center justify-center h-8 w-8 rounded-full bg-blue-600 text-white font-semibold text-sm">
                  {index + 1}
                </div>
              </div>
              <div className="flex-grow">
                <p className="text-gray-700">{step}</p>
              </div>
            </li>
          ))}
        </ol>
      </Card>

      {/* Video Links Section */}
      {diagnosis.videoLinks.length > 0 && (
        <Card className="p-6 shadow-lg">
          <div className="flex items-center gap-2 mb-4">
            <Video className="w-6 h-6 text-blue-600" />
            <h3 className="text-xl font-bold text-gray-900">
              Tutorial Videos
            </h3>
          </div>
          <div className="space-y-2">
            {diagnosis.videoLinks.map((link, index) => (
              <a
                key={index}
                href={link.url}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-between p-3 bg-blue-50 hover:bg-blue-100 rounded-lg border border-blue-200 transition group"
              >
                <span className="text-blue-600 font-medium group-hover:text-blue-700">
                  {link.title}
                </span>
                <ExternalLink className="w-4 h-4 text-blue-600 group-hover:translate-x-1 transition" />
              </a>
            ))}
          </div>
        </Card>
      )}

      {/* Parts Section */}
      {diagnosis.parts.length > 0 && (
        <Card className="p-6 shadow-lg">
          <div className="flex items-center gap-2 mb-4">
            <Package className="w-6 h-6 text-blue-600" />
            <h3 className="text-xl font-bold text-gray-900">
              Required Parts
            </h3>
          </div>
          <div className="space-y-2">
            {diagnosis.parts.map((part, index) => (
              <div
                key={index}
                className="flex items-center justify-between p-3 bg-gray-50 rounded-lg border border-gray-200"
              >
                <span className="text-gray-700 font-medium">{part.name}</span>
                <span
                  className={`text-xs font-semibold px-3 py-1 rounded-full ${getAvailabilityColor(
                    part.availability
                  )}`}
                >
                  {part.availability}
                </span>
              </div>
            ))}
          </div>
        </Card>
      )}
    </div>
  );
}
